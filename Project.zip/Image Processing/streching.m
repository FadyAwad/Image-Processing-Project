function [ new_img] = streching(  input_img1,new_min,new_max )
input_img=double(input_img1);
old_min=min(min(input_img));
old_max=max(max(input_img));
[w,h]=size(input_img1);
new_img=zeros(w,h);
for n=1:w
   for j=1:h
          new_img(n,j)=(((input_img(n,j)-old_min)/(old_max-old_min))*(new_max-new_min))+new_min;
   end
end
end


