function [bin]=grayTobin(Img)
bin =imbinarize(img);
imshow(bin);
end

