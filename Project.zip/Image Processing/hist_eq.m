function [  ] = hist_eq( input_image )
 [h,w]=size(input_image);
 ha=host(input_image);
 ca=ones(256,1);
 na=ones(256,1);
 ca(1)=ha(1);
  for m=2:256
      ca(m)=ca(m-1)+ha(m);
  end
 for i=1:256
    na(i)=(ca(i)-ca(1))/((w*h)-ca(1))*255; 
 end
bar(na);
end