function [ new_image] = streching( image,old_min,old_max,new_min,new_max)
[H W L] = size(image);
new_image = zeros(H,W);
new_image = double(new_image);
for i=1 :H
    for j=1 :W
       new_image(i,j) = (((image(i,j)-old_min)/(old_max-old_min))*(new_max-new_min))+new_min; 
    end
end
new_image = uint8(new_image);
figure, imshow(new_image);

end

