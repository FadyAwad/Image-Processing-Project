function [ N,A] = my_log(  input_img,a )
i=im2double(input_img);
[w,h]=size(input_img);
for n=1:w
   for j=1:h
           %A(n,j)=1-(i(n,j)^a);
           N(n,j)=a*log(i(n,j)+1);
           A(n,j)=exp(i(n,j)^(a))-1;
   end
end
figure,imshow(input_img);
figure,imshow(N);
figure,imshow(A);
end
