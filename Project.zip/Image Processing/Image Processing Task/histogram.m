function [ ] = histogram(img)
hist_arr =zeros(265,1);
[H W L] = size(img);
for i=1 : H
    for j=1 : W
        hist_arr(img(i,j)+1) = hist_arr(img(i,j)+1) + 1;
    end
end
bar(hist_arr);

end

