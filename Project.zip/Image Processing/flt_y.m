function [ output_img ] = flt_y( input_img,option )
%mask=[0 -1 0;-1 5 -1;0 -1 0];
%mask=[-1 -1 -1;-1 8 -1;-1 -1 -1];
%mask=[-1 -2 -1;0 0 0;1 2 1];
mask_blure=[1 1 1;1 1 1;1 1 1]/9;
mask_blure1=[1 1 1;1 2 1;1 1 1]/10;
%44444444444444444444edge
mask_edge_point=[-1 -1 -1;-1 8 -1;-1 -1 -1];
mask_edge_dl=[0 -1 -2;1 0 -1;2 1 0];
mask_edge_h=[-1 -2 -1;0 0 0;1 2 1];
mask_edge_dr=[-2 -1 0;-1 0 1;0 1 2];
mask_edge_v=[-1 0 1;-2 0 2;-1 0 1];
%4444444444444444444
mask_sharping_point=[0 -1 0;-1 5 -1;0 -1 0];
mask_sharping_dl=[0 0 1;0 1 0;-1 0 0];
mask_sharping_h=[0 1 0;0 1 0;0 -1 0];
mask_sharping_br=[1 0 0;0 1 0;0 0 -1];
mask_sharping_v=[0 0 0;1 1 -1;0 0 0];
if option==1
    aa=filter2(mask_blure,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==13
    aa=filter2(mask_blure1,input_img);
    output_img=aa/255;
    imshow(output_img);
end
%///////////////////////////2 to 6 edge 
if option==2
    aa=filter2(mask_edge_point,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==3
    aa=filter2(mask_edge_dl,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==4
    aa=filter2(mask_edge_h,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==5
    aa=filter2(mask_edge_dr,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==6
    aa=filter2(mask_edge_v,input_img);
    output_img=aa/255;
    imshow(output_img);
end
%///////////////////////////7 to 11 sharping 
if option==7
    aa=filter2(mask_sharping_point,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==8
    aa=filter2(mask_sharping_dl,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==9
    aa=filter2(mask_sharping_h,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==10
    aa=filter2(mask_sharping_br,input_img);
    output_img=aa/255;
    imshow(output_img);
end
if option==11
    aa=filter2(mask_sharping_v,input_img);
    output_img=aa/255;
    imshow(output_img);
end
end

