
function varargout = fadyGUI(varargin)
% FADYGUI MATLAB code for fadyGUI.fig
%      FADYGUI, by itself, creates a new FADYGUI or raises the existing
%      singleton*.
%
%      H = FADYGUI returns the handle to a new FADYGUI or the handle to
%      the existing singleton*.
%
%      FADYGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FADYGUI.M with the given input arguments.
%
%      FADYGUI('Property','Value',...) creates a new FADYGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fadyGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fadyGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fadyGUI

% Last Modified by GUIDE v2.5 19-Oct-2023 10:25:58

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fadyGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @fadyGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fadyGUI is made visible.
function fadyGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fadyGUI (see VARARGIN)

% Choose default command line output for fadyGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes fadyGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = fadyGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
a=str2num(get(handles.as1,'string'));
global input_img;
a=brightness( input_img , a , 1 );
axes(handles.axes8);
imshow(a);

% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function as1_Callback(hObject, eventdata, handles)
% hObject    handle to as1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of as1 as text
%        str2double(get(hObject,'String')) returns contents of as1 as a double


% --- Executes during object creation, after setting all properties.
function as1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to as1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in a1.
function a1_Callback(hObject, eventdata, handles)
% hObject    handle to a1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns a1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from a1


% --- Executes during object creation, after setting all properties.
function a1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in a2.
function a2_Callback(hObject, eventdata, handles)
% hObject    handle to a2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns a2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from a2


% --- Executes during object creation, after setting all properties.
function a2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
a1=get(handles.a1,'value');
a2=get(handles.a2,'value');
global input_img;
if (a1==1&&a2==1)
    axes(handles.axes8);
    imshow(input_img);
end
if (a1==2&&a2==2)
    axes(handles.axes8);
    imshow(input_img);
end
if (a1==3&&a2==3)
    axes(handles.axes8);
    imshow(input_img);
end
if (a1==1&&a2==2)
    a=rgptog(input_img);
    axes(handles.axes8);
    imshow(a);
end
if (a1==1&&a2==3)
    a=rgptob(input_img);
    axes(handles.axes8);
    imshow(a);
end
if (a1==2&&a2==3)
    a=RGBtogray(input_img,150);
    axes(handles.axes8);
    imshow(a);
end
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
a=str2num(get(handles.as1,'string'));
global input_img;
a=brightness( input_img , a , 4 );
axes(handles.axes8);
imshow(a);
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
a=str2num(get(handles.as1,'string'));
global input_img;
a=brightness( input_img , a , 2 );
axes(handles.axes8);
imshow(a);
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
a=str2num(get(handles.as1,'string'));
global input_img;
a=brightness( input_img , a , 3 );
axes(handles.axes8);
imshow(a);
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
a=str2num(get(handles.asd,'string'));
global input_img;
a =input_img;
axes(handles.axes8);
imshow(a);
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function asd_Callback(hObject, eventdata, handles)
% hObject    handle to asd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of asd as text
%        str2double(get(hObject,'String')) returns contents of asd as a double


% --- Executes during object creation, after setting all properties.
function asd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to asd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
global input_img;
z =negative(input_img);
axes(handles.axes8);
imshow(z);
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton19.
function pushbutton19_Callback(hObject, eventdata, handles)
a=str2num(get(handles.asd,'string'));
global input_img;
z =log(input_img,a);
axes(handles.axes8);
imshow(z);
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton20.
function pushbutton20_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
a=str2num(get(handles.asd,'string'));
global input_img;
z =Gamma(input_img,a);
axes(handles.axes8);
imshow(z);
% hObject    handle to pushbutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
a=str2num(get(handles.asd,'string'));
global input_img;
z =host(input_img);
axes(handles.axes8);
bar(z);
% hObject    handle to pushbutton23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton24.
function pushbutton24_Callback(hObject, eventdata, handles)
global input_img;
a=streching( input_img,0,1);
axes(handles.axes8);
imshow(a);

% hObject    handle to pushbutton24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton25.
function pushbutton25_Callback(hObject, eventdata, handles)
global input_img;
ta=h_eq( input_img );
axes(handles.axes8);
imshow(ta);
% hObject    handle to pushbutton25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function az2_Callback(hObject, eventdata, handles)
% hObject    handle to az2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of az2 as text
%        str2double(get(hObject,'String')) returns contents of az2 as a double


% --- Executes during object creation, after setting all properties.
function az2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to az2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function az1_Callback(hObject, eventdata, handles)
% hObject    handle to az1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of az1 as text
%        str2double(get(hObject,'String')) returns contents of az1 as a double


% --- Executes during object creation, after setting all properties.
function az1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to az1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)

y=get(handles.listbox1,'value');
switch(y)
    case 1
        x=[1/9 1/9 1/9;1/9 1/9 1/9;1/9 1/9 1/9;];
        set(handles.uitable4,'data',x);
    case 2
        x=[1/16 2/16 1/16;2/16 4/16 2/16;1/16 2/16 1/16;];
        set(handles.uitable4,'data',x);
    case 3
        x=[0 -1 0;-1 4 -1;0 -1 0;];
        set(handles.uitable4,'data',x);
    case 4
        x=[-1 -1 -1;-1 8 -1;-1 -1 -1;];
        set(handles.uitable4,'data',x);
    case 5
        x=[0 -1 0;-1 5 -1;0 -1 0;];
        set(handles.uitable4,'data',x);
    case 6
        x=[-1 -1 -1;-1 9 -1;-1 -1 -1;];
        set(handles.uitable4,'data',x);
    case 7
        x=[-1 -2 -1;0 0 0;1 2 1;];
        set(handles.uitable4,'data',x);
    case 8
        x=[-1 0 1;-2 0 2;-1 0 1;];
        set(handles.uitable4,'data',x);
    case 9
        x=[0 -1 -2;1 0 -1;2 1 0;];
        set(handles.uitable4,'data',x);
    case 10
        x=[-2 -1 0;1 0 -1;0 1 2;];
        set(handles.uitable4,'data',x);
    case 11
        x=[0 1 0;0 1 0;0 -1 0;];
        set(handles.uitable4,'data',x);
    case 12
        x=[0 0 0;1 1 -1;0 0 0;];
        set(handles.uitable4,'data',x);
    case 13
        x=[0 0 1;0 1 0;-1 0 0;];
        set(handles.uitable4,'data',x);
    case 14
        x=[1 0 0;0 1 0;0 0 -1;];
        set(handles.uitable4,'data',x);
end;

% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton26.
function pushbutton26_Callback(hObject, eventdata, handles)
mask=get(handles.uitable4,'data');
con=get(handles.con,'value');
global input_img;
img=input_img;
new_img=fltar_y1a(img,mask );
if(con==1)
    mask=transpose(mask);
 new_img=fltar_y1a(img,mask );   
end
axes(handles.axes8);
imshow(new_img);



% hObject    handle to pushbutton26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in dd.
function dd_Callback(hObject, eventdata, handles)
% hObject    handle to dd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dd


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in pushbutton27.
function pushbutton27_Callback(hObject, eventdata, handles)
global input_img;
a=get(handles.dd,'value');
if(a==1)
 asad=FFT( input_img );
    axes(handles.axes8);
    imshow(asad);
end
% hObject    handle to pushbutton27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in axax.
function axax_Callback(hObject, eventdata, handles)
axax=get(handles.axax,'value');
global input_img;
switch (axax)
    case 1
    [asad,am]=cr( 15,input_img);
    axes(handles.axes8);
    imshow(asad);
    case 2
    [asad,am]=cr( 15,input_img);
    axes(handles.axes8);
    imshow(am); 
    case 3
    [asad,a]=buter( 15,input_img,2);
    axes(handles.axes8);
    imshow(asad);
    case 4
    [asad,a]=buter( 15,input_img,2);
    axes(handles.axes8);
    imshow(a);
    case 5
    [asad,a]=gaussian( 15,input_img);
    axes(handles.axes8);
    imshow(asad);
    case 6
    [asad,a]=gaussian( 15,input_img);
    axes(handles.axes8);
    imshow(a);
end
% hObject    handle to axax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns axax contents as cell array
%        contents{get(hObject,'Value')} returns selected item from axax


% --- Executes during object creation, after setting all properties.
function axax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in r1.
function r1_Callback(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of r1


% --- Executes on button press in r2.
function r2_Callback(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of r2


% --- Executes on button press in r3.
function r3_Callback(hObject, eventdata, handles)
% hObject    handle to r3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of r3


% --- Executes on button press in r4.
function r4_Callback(hObject, eventdata, handles)
% hObject    handle to r4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of r4


% --- Executes on button press in r5.
function r5_Callback(hObject, eventdata, handles)
% hObject    handle to r5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of r5


% --- Executes on button press in r6.
function r6_Callback(hObject, eventdata, handles)
% hObject    handle to r6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of r6


% --- Executes on button press in pushbutton29.
function pushbutton29_Callback(hObject, eventdata, handles)
r1=get(handles.r1,'value');
r2=get(handles.r2,'value');
r3=get(handles.r3,'value');
r4=get(handles.r4,'value');
r5=get(handles.r5,'value');
r6=get(handles.r6,'value');
ab=str2num(get(handles.as2as,'string'));
as=str2num(get(handles.as1as,'string'));
global input_img;
if r1==1
    a=Saltandpepper_noise(input_img,ab,as);
end
if r2==1
    a=Uniform_noise(input_img,ab,as);
end
if r3==1
    a=Gauss_noise( input_img,ab,as );
end
axes(handles.axes8);
        imshow(a);

% hObject    handle to pushbutton29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function as1as_Callback(hObject, eventdata, handles)
% hObject    handle to as1as (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of as1as as text
%        str2double(get(hObject,'String')) returns contents of as1as as a double


% --- Executes during object creation, after setting all properties.
function as1as_CreateFcn(hObject, eventdata, handles)
% hObject    handle to as1as (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton30.
function pushbutton30_Callback(hObject, eventdata, handles)
global input_img;
input_img = uigetfile('*.*');
input_img = imread(input_img);
axes(handles.axes4);
imshow(input_img);
set(handles.edit10,'string',input_img);
% hObject    handle to pushbutton30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton31.
function pushbutton31_Callback(hObject, eventdata, handles)
global input_img;
input_img=imread(input_img);
axes(handles.axes4);
imshow(input_img);
% hObject    handle to pushbutton31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function as2as_Callback(hObject, eventdata, handles)
% hObject    handle to as2as (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of as2as as text
%        str2double(get(hObject,'String')) returns contents of as2as as a double


% --- Executes during object creation, after setting all properties.
function as2as_CreateFcn(hObject, eventdata, handles)
% hObject    handle to as2as (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton32.
function pushbutton32_Callback(hObject, eventdata, handles)
f=getframe(handles.axes8);
im=frame2im(f);
imwrite(im,'imge.tif');
% hObject    handle to pushbutton32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in con.
function con_Callback(hObject, eventdata, handles)
% hObject    handle to con (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of con


% --------------------------------------------------------------------
function uitable4_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uitable4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
