function [ na ] = rgptog( i )
[w,h,l]=size(i);
for n=1:w
   for j=1:h
        na(n,j)=i(n,j,1);
        na1(n,j)=i(n,j,2);
        na2(n,j)=i(n,j,3);
        na3(n,j)=(i(n,j,1)+i(n,j,2)+i(n,j,3))/3;
        na4(n,j)=i(n,j,1)*.2+i(n,j,2)*.1+i(n,j,3)*.3; 
   end
end

end

