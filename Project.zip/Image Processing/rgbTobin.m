function [bin]= rgbTobin(rgb_img)
gray=rgb2gray(rgb_img);
bin=imbinarize(gray);
imshow(bin);
end