function [ hist ] = host( img )
[w,h,l]=size(img);
hist=zeros(256,1);
    for n=1:w
       for j=1:h
           hist(img(n,j)+1)=hist(img(n,j)+1)+1;
       end
    end
    bar(hist);
end

