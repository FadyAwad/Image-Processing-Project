function [ fi ] = FFT( img )
c=fft2(img);
cla=fftshift(c);
as=abs(cla);
clo=log(1+as);
fi=mat2gray(clo);
end