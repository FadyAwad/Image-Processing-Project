function [ new_imege ] = fltar_y1a( img,mask )
[w,h]=size(img);
%=[0 -1 0;-1 5 -1;0 -1 0];
img=im2double(img);
new_imege1=zeros(w+1,h+1);
%new_imege=zeros(h,w);
  for n=2:w
       for j=2:h
           new_imege1(n,j)=img(n-1,j-1);
       end
  end
    for n=2:w-1
       for j=2:h-1
           new_imege(n-1,j-1)=new_imege1(n,j)*mask(2,2)+new_imege1(n-1,j+1)*mask(1,3)+new_imege1(n-1,j)*mask(1,2)+new_imege1(n,j-1)*mask(2,1)+new_imege1(n-1,j-1)*mask(1,1)+new_imege1(n+1,j)*mask(3,2)+new_imege1(n,j+1)*mask(2,3)+new_imege1(n+1,j+1)*mask(3,3)+new_imege1(n+1,j-1)*mask(3,1);
       end
    end
end

