function [new_image] = LogFun(old_image,C)
z =im2double(old_image);
[H,W,F] = size(z);
new_image = zeros(H,W,F);

for i=1:H
    for j=1:W
        for k=1:F
        new_image(i,j,k) =C*log10(z(i,j,k)+1);
        end
    end
end
end

