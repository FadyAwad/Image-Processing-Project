function [ u ] = gray2bi( I,T )
[W,H,l]=size(I);

for i=1:W
    for j=1:H
        for k=1:l
        if I(i,j,k)<T
        u(i,j,k)=0;
        else u(i,j,k)=1;
        end
        end
    end
end
end