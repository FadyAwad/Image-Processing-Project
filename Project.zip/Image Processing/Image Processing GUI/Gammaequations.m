global GammaValue NewImage
[NewImage] = Gamma(NewImage,GammaValue);
app.Image_2.ImageSource=NewImage;
        
