function [new_image] = Negative_trans(old_image)
[H,W] = size(old_image);
new_image = zeros(H,W);

for i = 1:H
    for j = 1:W
        new_image(i,j) = 255 - old_image(i,j);
    end
end
imshow(new_image);

end

