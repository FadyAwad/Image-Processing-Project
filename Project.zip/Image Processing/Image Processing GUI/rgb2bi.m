function [rgb] = rgb2bi( I,T,o )
[W,H,l]=size(I);
z=rgb2grey(I,o);
[W,H,l]=size(z);
x=gray2bi(z,T);
rgb=x;
end