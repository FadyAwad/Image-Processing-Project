function result = HistEq(im)
    [H, W,F] = size(im);
    count = zeros(256, 1,F);
    
    % Count gray levels
    for i=1:H
        for j=1:W
            for k=1:F
            count(im(i, j,k) + 1) = count(im(i, j,k) + 1) + 1;
            end
        end
    end
    
    % PDF
    p = count / (H*W);
    cdf = zeros(256, 1);
    
    % CDF
    for i=1:256
        cdf(i) = p(i);
        if i ~= 1
            cdf(i) = cdf(i) + cdf(i - 1);
        end
    end
    
    % Mapping gray levels
    % r -> s
    s = round(255*cdf);
    
    result = zeros(H, W);
    for i=1:H
        for j=1:W
            for k=1:F
            result(i, j,k) = s(im(i, j,k) + 1);
            end
        end
    end
    
    result = uint8(result);
end