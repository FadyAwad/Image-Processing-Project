function hist_arr = histogram(img)
[H,W] = size(img);
hist_arr = zeros(255,1);
for i=1 : H
    for j=1 : W
      
        hist_arr(img(i,j)+1) = hist_arr(img(i,j)+1) + 1;
       
    end
end

end

