function [ bright ] = brightness( gray , offset , option )
%Function to brightnees gray photo

   [H,W,F] = size(gray) ;
   bright = zeros( H , W ,F) ;

   bright = double( bright ) ;
   
   for i = 1 : H
       for j = 1 : W
           for k=1:F
           
               if option == 1
               bright( i , j ,k) = gray( i , j ) + offset ;
           end
           
           if option == 2 
               bright( i , j,k ) = gray( i , j ) * offset ;
           end
           
           if option == 3
               bright( i , j ,k) = gray( i , j ) - offset ;
           end
           
           if option == 4
               bright( i , j,k ) = gray( i , j ) / offset ;
           end
           end
       end
   end

   bright = uint8(bright);
end