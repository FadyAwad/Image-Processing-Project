function [new_image] = Gamma(old_image,C)
z = im2double(old_image);
whos z
[H,W,F] = size(z);
new_image = zeros(H,W,F);

for i = 1:H
    for j = 1:W
        for k=1:F
        new_image(i,j) = z(i,j)^C;
        end
    end
end
% new_image = uint8(new_image);
end