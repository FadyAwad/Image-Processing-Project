function [ new_image] = streching(result,new_min,new_max)
[H,W] = size(result);
result = double(result);
new_image = zeros(H,W);
old_min=min(min(result));
old_max=max(max(result));
for i=1 :H
    for j=1 :W
     
       new_image(i,j) = (((result(i,j)-old_min)/(old_max-old_min))*(new_max-new_min))+new_min; 
    end
    
end
%new_image = uint8(new_image);
end

