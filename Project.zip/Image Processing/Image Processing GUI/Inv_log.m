function [new_image] = Inv_log(old_image,C)
z = im2double(old_image);
[H,W] = size(z);
new_image = zeros(H,W);

for i=1:H
    for j=1:W
        new_image(i,j)= exp(z(i,j)^1/C)-1;
    end
end
imshow(new_image);

end

