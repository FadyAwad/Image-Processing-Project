hist_arr =zeros(255,0)
