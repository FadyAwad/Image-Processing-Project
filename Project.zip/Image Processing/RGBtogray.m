function [gray] = RGBtogray(old_im,index)
[h,w,l]=size(old_im);
gray=zeros(h,w);
gray=double(gray);
for i=1:h
    for j=1:w
        if index==1
            gray(i,j)=(old_im(i,j,1)+old_im(i+j+2)+old_im(i+j+3))/3;
        end
        if index==2
            gray(i,j)=old_im(i,j,1);
        end
        if index==3
            gray(i,j)=old_im(i,j,2);
        end
        if index==4
            gray(i,j)=old_im(i,j,3);
        end
        if index==5
            gray(i,j)=old_im(i,j,1)*0.2+old_im(i,j,2)*0.3+old_im(i,j,3)*0.5;
        end
    end
end

gray =uint8(gray);            
end

