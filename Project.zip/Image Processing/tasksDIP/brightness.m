function [bright_img] =brightness(img,bright_value)
bright_img=img+bright_value;
imshow(brigh_img);
end

