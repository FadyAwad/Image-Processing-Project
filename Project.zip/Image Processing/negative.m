function [negative_img] =negative(img)
negative_img=255-img;
imshow(negative_img);
end

