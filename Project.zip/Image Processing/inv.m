function [ img1 ] = inv( img )
[h,w]=size(img);
img1=zeros(h,w);
%sum=-1i;
for u=1:h
    for v=1:w
        for x=1:h
          for y=1:w
              img1(u,v)=img1(u,v)+(img(x,y)*exp(((-1j)*2*pi((((u-1)*x)/h))+(((v-1)*y)/w))));
                % A(r,c)+(Mat(r,c)exp(((-1j)*2*pi(r-1)*(c-1))/rows));
          end
        end
    end
end
bakimg= ifft2(img1);
imshow(uint8(bakimg));
end

