function [ A ] = gamma_1(  input_img,a )
i=im2double(input_img);
[w,h]=size(input_img);
for n=1:w
   for j=1:h
           A(n,j)=(i(n,j))^a;      
   end
end
imshow(A);
figure,imshow(input_img);
end

