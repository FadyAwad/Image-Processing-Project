function [new_image] = log(old_image,C)
z =im2double(old_image);
[H,W] = size(z);
new_image = zeros(H,W);

for i=1:H
    for j=1:W
        new_image(i,j) =C*log10(z(i,j)+1);
    end
end
imshow(new_image);

end

