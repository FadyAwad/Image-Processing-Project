function [ newim ] = Gauss_noise( I,v,m )
img=double(I); 
[h w l]=size(img);
for i=1:255 
    num_of_pixels=round(((exp(-((i-m)^2/(2*v*v))))/(sqrt(2*3.14*v*v)))*w*h);
    for x=1:num_of_pixels 
        row=ceil(rand(1,1)*h);
        colom=ceil(rand(1,1)*w);
        img (row,colom)=img (row,colom)+i;
    end
end
for k=1:1
    mn =min(min(img(:,:,k)));
    mx=max(max(img(:,:,k)));
    new_img(:,:,k)=((img(:,:,k)-mn)/(mx-mn))*255;
end
newim=uint8(new_img);
end
