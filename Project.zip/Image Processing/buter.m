function [img1,img2] = buter( D0,img,t)
[h w]=size(img);
f=zeros(h,w);
f2=zeros(h,w);
c=fft2(img);
cla=fftshift(c);
r=real(cla);
im=imag(cla);

for a=1:h
    for j=1:w
        d=sqrt((a-h/2)^2+(j-w/2)^2);
        f(a,j)=1/(1+(d/D0)^(2*t));
        f2(a,j)=1/(1+(D0/d)^(2*t));
    end
end    

nr=r.*f;
ir=im.*f;
nft=nr+i*ir;
cl=fftshift(nft);
bakimg= ifft2(cl);
img1=uint8(bakimg)
nr1=r.*f2;
ir1=im.*f2;
nft1=nr1+i*ir1;
cl1=fftshift(nft1);
bakimg1= ifft2(cl1);
img2=uint8(bakimg1)
end

