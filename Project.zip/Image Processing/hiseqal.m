function []=hiseqal(img)
    [h w ]=size(img);
    prob=zeros(256,1);
    prob=host(img);
    s=zeros(256,1);
    %propability of each pixel
    for i=1:256
        prob(i)=prob(i)/(h*w);
    end
    %sum
    s(1)=prob(1);
    for i=2:256
        s(i)=prob(i)+s(i-1);
    end
    s=round(s*255);
    eq=zeros(h,w);
    for i=1:h
        for j=1:w
            t=img(i,j)+1;
            eq(i,j)=s(t);
        end
    end
    eq=uint8(eq);
    figure,imshow(eq)
    figure,host(eq);