function [ ] = hist_eq_y( input_image )
 [h,w]=size(input_image);
 ha=host(input_image);
    for i=1:256
        ha(i)=ha(i)/(h*w);
    end
 ca=zeros(256,1);
 ca(1)=ha(1);
  for m=2:256
      ca(m)=ca(m-1)+ha(m);
  end
  ca=round (ca*255);
    eq=zeros(h,w);
    for ia=1:h
        for ja=1:w
            eq(ia,ja)=ca(input_image(ia,ja)+1);
        end
    end
 eq=uint8(eq);
    figure,imshow(eq)
    figure,host(eq);
end

